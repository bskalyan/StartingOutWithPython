# this program displays an empty window.

import tkinter

def main():
    # create the main window widget.
    main_window=tkinter.Tk()
    
    # enter the tkinter main loop.
    tkinter.mainloop()
    
# call the main function
main()