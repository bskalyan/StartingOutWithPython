# this program demonstrates the split method.

def main():
    # create a string with multiple words.
    my_string="One two three four"
    
    # split the string
    word_list=my_string.split()
    
    # print the list of words. it is a list now
    print(word_list)
    
# call the main function
main()