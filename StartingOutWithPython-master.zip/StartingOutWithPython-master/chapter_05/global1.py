# create a global variable.
my_value=10

# the show_value function prints
# the value of the global variable

def show_value():
    print(my_value)

# call the show_value function
show_value()