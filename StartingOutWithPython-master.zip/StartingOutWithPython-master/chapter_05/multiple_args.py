# this program demonstrates a function that accepts
# two arguments

def main():
    print("The sum of 12 and 45 is")
    show_sum(12,45)

# the show_sum function accepts two arguments
# and displays their sum.

def show_sum(num1,num2):
    result=num1+num2
    print(result)

# call the main function
main()