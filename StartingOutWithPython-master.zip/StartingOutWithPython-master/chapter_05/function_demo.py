# this program demonstrates a function.
# first, we define a function named message.

def message():
    print("My name is Mehmet.")
    print("Author of this program.")

# call the message function    
message()