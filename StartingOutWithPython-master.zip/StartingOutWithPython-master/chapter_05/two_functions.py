# this program has two functions. first
# we define main function

def main():
    print("I have a message for you.")
    message()
    print("Goodbye!")
    
# next we define the message function.
def message():
    print("I am Mehmet.")
    print("The author of this program.")

# call the main function to execute
main()