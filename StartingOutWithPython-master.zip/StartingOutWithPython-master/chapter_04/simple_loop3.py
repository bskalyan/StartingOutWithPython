# this program also demonstrates a sample for 
# loop that uses a list of strings.

for name in ["Winken", "Blinken", "Nod"]:
    print(name)