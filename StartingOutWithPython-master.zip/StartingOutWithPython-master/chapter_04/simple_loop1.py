# this program demonstrates a sample for loop that uses a list of numbers

print("I will display the numbers 1 through 5.")
for num in [1,2,3,4,5]:
    print (num)
