# This program compares two strings
# Get a password from the user.
password=input("Please enter the password: ")

# Determine whether the correct password was entered.
if password=="prospero":
    print("Password accepted")
else:
    print("Wrong password.")