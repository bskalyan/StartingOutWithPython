# Starting Out with Python (3rd Edition) by Tony Gaddis

<p align="center">
  <img width="300" height="400" src="https://github.com/mmustafaicer/StartingOutWithPython/blob/master/book_cover.jpg?raw=true">
</p>

The codes of examples and programming exercises for [Starting Out With Python 3rd Edition](https://www.amazon.com/Starting-Out-Python-Tony-Gaddis/dp/0133582736) by Tony Gaddis 
prepared by Mehmet Icer for teaching purposes. Feel free to use and edit.

End of chapter questions are marked by
q01.py,
q02.py,
q03.py ,
etc.

If there is an alternative version it is numbered as q03_1.py (Alternative to q03.py)

Thanks.
for any inquiries
mmustafaicer@gmail.com
