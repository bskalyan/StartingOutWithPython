# This program displays a person's
# name and address
print("Mehmet Icer")
print("Dallas, TX.")