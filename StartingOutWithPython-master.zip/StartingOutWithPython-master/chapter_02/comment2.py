print("Mehmet Icer")            # Print name
print("Dallas TX")      # Print street name or address
# Variables
width=10
length=5
print (width)       # Variable name in parantheses
print (length)