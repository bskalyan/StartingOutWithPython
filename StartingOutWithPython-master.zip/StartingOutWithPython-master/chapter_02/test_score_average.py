# Calculate the average score of three different exam
# Get the exam grades
exam1=float(input("What is the score for exam 1: "))
exam2=float(input("What is the score for exam 2: "))
exam3=float(input("What is the score for exam 3: "))

# Get the average of three exams.
average=(exam1+exam2+exam3)/3

print("Your average is ", average)