# Get the first name
first_name=input("What is your first name: ")
# Get the last name
last_name=input("What is your last name: ")
print("Hello", first_name, last_name)


hours=int(input("How many hours do you work?: ")) # Every input is stored as string. So we use int

print(hours*4)