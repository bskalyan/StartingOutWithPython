# 1 
height=int(input("Enter your height in cm: "))
# 2
fav_color=input("Enter your favorite color: ")
# 3
b=a+2
a=4*b
b=a/3.14
a=b-8
# 4
# a = 12 , b=4, c=2.0, d=6, e=2

#5 

total=10+14

# 6

due=total-down_payment

# 7

total=subtotal*0.15

# 8 the answer is 11

# 9 the answer is 5

# 10
print(sales, '.2f')

# 11

number = 1234567.456
print(format(number, '12,.1f'))

# 12 it will display George@John@Paul@Ringo