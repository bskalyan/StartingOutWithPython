# This program demonstrates a variable
room = 503
print ("I am staying in room number " + str(room)) # You can make number string then concatenate

# Or

print("I am staying in room number")
print(room)