# This program demonstrates a variable.
room=503
print('I am staying in room number', room)

# or again you can concatenate. Since room is integer, you have to make it string first using
# str function

print("I am staying in room number " + str(room))