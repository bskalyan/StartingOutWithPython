# Create variables to reference two strings.
first_name="Mehmet"
last_name="Icer"
print(first_name, last_name)