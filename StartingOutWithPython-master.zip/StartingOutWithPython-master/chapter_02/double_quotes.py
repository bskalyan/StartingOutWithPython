print('Mehmet Mustafa Icer')
print("1004 Cleveland St")
print('Denton, TX. 76201')
#You can use single-quote marks or double in Python.