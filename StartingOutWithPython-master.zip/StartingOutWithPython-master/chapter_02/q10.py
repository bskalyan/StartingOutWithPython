# Ingredient Adjuster

# Ask user how many cookies he or she wants
cookie=int(input("Enter the amount of cookies you want: "))

# Find the ingredients (Simple ratio and proportion

sugar=cookie*(1.5)/48
butter=cookie*(1)/48
flour=cookie*(2.75)/48

print()
print("You will need following ingredients: ")
print(sugar, "cups of sugar")
print(butter, "cups of butter")
print(flour, "cups of flour")

