# Distance Traveled

speed=70

# The distance in 6 hours
print("The distance the car will travel in 6 hours is", speed*6, "miles")
print("The distance the car will travel in 10 hours is", speed*10, "miles")
print("The distance the car will travel in 15 hours is", speed*15, "miles")