# This program demonstrates variable reassignment
dollars=2.75
print("I have", dollars, "in my account.")
dollars=99.95
print("But now, I have", dollars, "in my account.") # We changed or reassigned the dollars variable.
