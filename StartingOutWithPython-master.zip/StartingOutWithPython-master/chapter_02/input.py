# Get the user's name. age, and income.
name = input("What is your name: " )
age = int(input("What is your age?: "))
income = float(input("What is your income?: "))

# Display the data.
print()
print("Here is the data you entered.")
print("Name: ", name)
print("Age: ", age)
print("Income: ", income)

# Checkpint 2.17 and 2.18
last_name=input("Please enter your last name: ")
sales_week=float(input("Please enter the amount of sales for the week: "))