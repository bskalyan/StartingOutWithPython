# Assign a value to the salary variable.
salary=float(input("What is your salary?: "))
bonus=float(input("What is your bonus?: "))

# Calculate the total pay by adding salary
total_pay=salary+bonus
print("Your total pay is", total_pay)