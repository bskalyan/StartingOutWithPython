# Get the original price
original_price=float(input("What is the price of this product: "))
# Calculate the discounted amount
discounted=original_price*(0.2)
# Subtract the discounted amount from original price.
final_price=original_price-discounted
# Show the final price
print("The price after %20 discount is", final_price )
