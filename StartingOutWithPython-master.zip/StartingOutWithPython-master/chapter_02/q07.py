# Miles-per-Gallon

miles=float(input("Enter the number of miles driven: "))
gas=float(input("Enter the amount of gallons of gas used: "))

mpg=miles//gas

print("Your car's mpg is ", mpg)