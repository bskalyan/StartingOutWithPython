# Personal Information

name=input("Please enter your name: ")
address=input("Please enter your address with city, state and ZIP code: ")
tel=input("Please enter your phone number: ")
col_major=input("Please enter your college major: ")


print()
# Show the information that is provided by user.
print("Your information is below: ")

print("Your name: ", name)
print("Your address is ", address)
print("Your phone number is ",tel)
print("Your major is ", col_major)