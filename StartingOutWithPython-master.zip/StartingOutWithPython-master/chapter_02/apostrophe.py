print("Don't fear")
print("I'm here!")

#Display quote
print('Your assignment is to read "Hamlet" by tomorrow.')
#Triple quotes also work
print("""I'm reading "Hamlet" tonight.""")
print("""One
Two
Three""")

#Checkpoint
print("Python's the best")
print('The cat said "meow"')