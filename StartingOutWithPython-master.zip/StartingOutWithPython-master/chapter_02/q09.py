# Celcius to Fahrenheit Temperature Converter

# ask user to enter a temperature in Celcius.
celcius=float(input("Please enter the temperature in Celcius: "))
fahrenheit=(9/5)*celcius+32

print(celcius, "celcius equals to", fahrenheit, "fahrenheit degrees.")